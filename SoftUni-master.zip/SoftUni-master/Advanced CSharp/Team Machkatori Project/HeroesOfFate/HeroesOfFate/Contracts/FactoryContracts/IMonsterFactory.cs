﻿namespace HeroesOfFate.Contracts.FactoryContracts
{
    public interface IMonsterFactory
    {
         
    }
}