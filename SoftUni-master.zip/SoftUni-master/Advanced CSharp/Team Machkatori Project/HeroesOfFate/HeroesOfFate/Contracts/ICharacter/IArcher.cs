﻿namespace HeroesOfFate.Contracts.ICharacter
{
    public interface IArcher
    {
         
    }
}