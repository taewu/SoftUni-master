﻿namespace HeroesOfFate.Contracts.ICharacter
{
    public interface IWarrior
    {
         
    }
}