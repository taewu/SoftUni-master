﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroesOfFate.Contracts
{
    public interface IHealth
    {
        double HealthEffect { get; set; }
    }
}
