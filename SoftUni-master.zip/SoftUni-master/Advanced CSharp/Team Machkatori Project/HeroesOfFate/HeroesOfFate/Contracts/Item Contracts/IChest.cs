﻿namespace HeroesOfFate.Contracts
{
    public interface IChest
    {
        string Id { get; set; } 
    }
}