﻿namespace HeroesOfFate.Contracts
{
    public interface IGoldChest
    {
        double Gold { get; set; }

        int Exp { get; set; }
    }
}