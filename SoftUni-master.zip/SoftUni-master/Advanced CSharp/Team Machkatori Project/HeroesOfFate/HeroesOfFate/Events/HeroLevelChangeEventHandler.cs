﻿namespace HeroesOfFate.Events
{
    public delegate void HeroLevelChangeEventHandler(object sender, HeroChangeLevelEventArgs eventArgs);
}
