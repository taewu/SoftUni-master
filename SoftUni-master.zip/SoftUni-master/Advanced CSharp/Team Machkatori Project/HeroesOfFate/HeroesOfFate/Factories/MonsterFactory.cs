﻿namespace HeroesOfFate.Factories
{
    public class MonsterFactory
    {
         
    }
}