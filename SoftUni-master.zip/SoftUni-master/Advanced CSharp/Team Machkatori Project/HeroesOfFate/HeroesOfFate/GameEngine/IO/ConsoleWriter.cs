﻿using System;

namespace HeroesOfFate.GameEngine.IO
{
    public class ConsoleWriter
    {
        public void PrintCommand(string message)
        {
            Console.WriteLine(message);
        }
    }
}