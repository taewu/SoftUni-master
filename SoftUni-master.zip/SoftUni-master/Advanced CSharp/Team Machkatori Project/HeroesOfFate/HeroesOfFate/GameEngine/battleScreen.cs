﻿

namespace HeroesOfFate.GameEngine
{
    static class battleScreen
    {
        public static void drawBattleScreen()
        {
            System.Console.Clear();
            System.Console.WriteLine("you are engad in battle");
        }
    }
}
