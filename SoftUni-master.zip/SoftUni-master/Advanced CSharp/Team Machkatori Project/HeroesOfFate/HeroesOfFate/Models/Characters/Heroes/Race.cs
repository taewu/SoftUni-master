﻿namespace HeroesOfFate.Models.Characters.Heroes
{
    public enum Race
    {
        Human,
		Elf,
		Orc,
		Dwarf,
		Werewolf
    }
}
