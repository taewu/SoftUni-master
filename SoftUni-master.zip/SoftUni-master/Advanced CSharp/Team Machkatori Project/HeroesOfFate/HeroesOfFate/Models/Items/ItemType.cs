﻿namespace HeroesOfFate.Models.Items
{
    public enum ItemType
    {
        Helmet,
        MainHand,
        OffHand,
        Body,
        Legs,
        Gloves,
        Boots,
        Potion
    }
}
