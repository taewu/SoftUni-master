﻿namespace Empire.Enums
{
    public enum ResourceType
    {
        Gold,
        Steel
    }
}