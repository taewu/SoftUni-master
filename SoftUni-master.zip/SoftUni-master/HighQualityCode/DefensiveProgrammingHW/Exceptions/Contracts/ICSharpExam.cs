﻿namespace Exceptions.Contracts
{
    public interface ICSharpExam : IExam
    {
        int Score { get; } 
    }
}