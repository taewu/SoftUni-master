﻿namespace Exceptions.Contracts
{
    public interface ISimpleMathExam : IExam
    {
         int ProblemsSolved { get; }
    }
}