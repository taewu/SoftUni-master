﻿namespace LoggerLibrary.Models
{
    public enum ReportLevel
    {
        Info,
        Warning,
        Error,
        Critical,
        Fatal 
    }
}