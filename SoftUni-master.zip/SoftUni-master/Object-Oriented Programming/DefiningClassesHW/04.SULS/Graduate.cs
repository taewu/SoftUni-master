﻿namespace SULS
{
    public class Graduate : Student
    {
        public Graduate(string firstName, string lastName, int age, string studentNumber, decimal avrgGrade) 
            : base(firstName, lastName, age, studentNumber, avrgGrade)
        {

        }
    }
}
