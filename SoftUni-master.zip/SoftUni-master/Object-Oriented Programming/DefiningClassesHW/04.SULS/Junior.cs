﻿namespace SULS
{
    class Junior : Trainer
    {
        public Junior(string firstName, string lastName, int age) 
            : base(firstName, lastName, age)
        {

        }
    }
}
