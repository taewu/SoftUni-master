﻿namespace SULS
{
    public class Online : Current
    {
        public Online(string firstName, string lastName, int age, string studentNumber, decimal avrgGrade, string currentCourse)
            : base(firstName, lastName, age, studentNumber, avrgGrade, currentCourse)
        {

        }
    }
}
