﻿namespace BankOfKurtovoKonare
{
    public enum Customer
    {
        Individual, 

        Company
    }
}