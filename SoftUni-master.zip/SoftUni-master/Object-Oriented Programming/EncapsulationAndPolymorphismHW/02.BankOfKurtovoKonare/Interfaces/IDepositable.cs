﻿namespace BankOfKurtovoKonare.Interfaces
{
    public interface IDepositable
    {
        void DepositMoney(decimal money);
    }
}