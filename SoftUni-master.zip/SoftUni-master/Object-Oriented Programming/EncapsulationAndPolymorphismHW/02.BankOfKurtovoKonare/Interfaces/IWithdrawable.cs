﻿namespace BankOfKurtovoKonare.Interfaces
{
    public interface IWithdrawable
    {
        void WithdrawMoney(decimal money);
    }
}