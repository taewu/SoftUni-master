﻿namespace TheSlum
{
    using TheSlum.GameEngine;

    public class TheSlumRun
    {
        public static void Main()
        {
            Engine engine = new AdvancedEngine();
            engine.Run();
        }
    }
}