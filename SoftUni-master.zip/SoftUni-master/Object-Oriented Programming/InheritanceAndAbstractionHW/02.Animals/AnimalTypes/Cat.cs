﻿namespace Animals.AnimalTypes
{
    public abstract class Cat : Animal
    {
        protected Cat(string name, int age, string gender) : base(name, age, gender) 
        {
            
        }
    }
}