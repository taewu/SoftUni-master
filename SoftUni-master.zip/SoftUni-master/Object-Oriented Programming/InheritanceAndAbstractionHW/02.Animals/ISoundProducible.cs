﻿using System.Security.Cryptography.X509Certificates;

namespace Animals
{
    public interface ISoundProducible
    {
        string ProduceSound();
    }
}