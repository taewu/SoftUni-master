﻿namespace CompanyHierarchy.Interfaces
{
    public interface ICustomer
    {
        decimal NetPurchaseAmount { get; set; }
    }
}