﻿using System;

namespace _01.Point3D
{
    class Point3DMain
    {
        static void Main()
        {
            Point3D point = new Point3D(1.3919023f, 6.12837912f, 10.391283f);

            Console.WriteLine(point.ToString());
        }
    }
}
