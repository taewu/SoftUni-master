﻿namespace Geometry.Geometry2D
{
    public class Circle
    {
         
    }
}