﻿namespace Geometry.Geometry2D
{
    public class DistanceCalculator2D
    {
         
    }
}