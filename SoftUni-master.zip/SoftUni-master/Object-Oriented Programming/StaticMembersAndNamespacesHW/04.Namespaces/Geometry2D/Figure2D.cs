﻿namespace Geometry.Geometry2D
{
    public class Figure2D
    {
         
    }
}